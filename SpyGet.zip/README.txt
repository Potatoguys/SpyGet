WARNING! "SpyGet.bat" is malware, and it WILL perform unwanted actions on your computer. These actions include:

-Swapping the mouse buttons. (left click becomes right click, and vice versa)
-Gathering the systems public and private IP address.
-Gathering WiFi names, and passwords of WiFi networks on this system.
-Sending the following information to an Email address: Your username, your public IPv4 address, your private IPv4 address, WiFi network names, and passwords, and the time your system was infected.
-Killing the explorer task. (meaning, the desktop and taskbar, will disappear)
-Powering your computer off.


If you still wish to run "SpyGet.bat" follow these instructions:

-Double-click on "SpyGet.bat". (you can find "SpyGet.bat" in the zip-folder called "SpyGet")
WARNING! "SpyGet.bat" is malware, and it WILL perform unwanted actions on your computer. These actions include:

-Swapping the mouse buttons. (left click becomes right click, and vice versa)
-Gathering the systems public and private IP address.
-Gathering WiFi names, and passwords of all saved WiFi networks on this system.
-Sending the following information to an Email address: Your username, your public IPv4 address, your private IPv4 address, all saved WiFi network names, and passwords, time your system was infected.
-Killing the explorer task. (meaning, the desktop and taskbar, will disappear)
-Powering your computer off.


If you still wish to run "SpyGet.bat" follow these instructions:

-Double-click on "SpyGet.bat". (you can find "SpyGet.bat" in the zip-folder called "SpyGet")
-You will see a message saying that you should extract the files, click on "Run".
-You will now see a message saying that Windows protected your computer. To run "SpyGet.bat" anyways, click on "More info", and then click on "Run anyways".
-"SpyGet.bat" will now start, and you will be greeted by a consent prompt before the malware portion starts.


The SMPT server "SpyGet.bat" sends the information to is: "smtp.ethereal.email".
The Email address "SpyGet.bat" sends the information to is "luz.zieme64@ethereal.email". This Email address shall be made public for anyone to access.
If you wish to view the Emails sent to "luz.zieme64@ethereal.email" follow these instructions:

-Go to the domain: "https://ethereal.email/login"
-Enter: "luz.zieme64@ethereal.email" in the "Enter email" section.
-Enter: "uRBhtZPkNqqyN73qKN" in the "Password" section.
-Click on "Log in".
-Click on the "Messages" field on the top of the page.
-Here you will see all traffic that "luz.zieme64@ethereal.email" receives.


If you do not wish to use, or possess this malware, follow these instructions:

-Click on the Windows key on your keyboard.
-Search for "File explorer"
-Click on "Open"
-You will see a bunch of folders and such on the left, find the one named "This PC" and click on it.
-To the top-right there is a search field. Search for "SpyGet".
-Right-click on "SpyGet.zip", and click on "Open file placement"
-You will then see a file named "SpyGet.zip". Right-click on the date it was last changed on, and click "Delete"
-This malware will no longer be on your computer.

Please do not use this malware for illegal/malicious purposes.
This malware was made strictly for EDUCATIONAL purposes, and I do not condone or endorse any malicious use.